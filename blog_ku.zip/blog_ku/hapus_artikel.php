<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "Artikel tidak ditemukan.";
    exit;
}

$article_id = intval($_GET['id']);

// Ambil URL gambar untuk dihapus (opsional)
$result = $conn->query("SELECT image_url FROM article WHERE id = $article_id");
if ($result->num_rows === 0) {
    echo "Artikel tidak ditemukan.";
    exit;
}
$row = $result->fetch_assoc();
$image_path = $row['image_url'];

// Hapus relasi dari tabel penghubung
$conn->query("DELETE FROM article_author WHERE article_id = $article_id");
$conn->query("DELETE FROM article_category WHERE article_id = $article_id");

// Hapus artikel
$conn->query("DELETE FROM article WHERE id = $article_id");

// (Opsional) Hapus file gambar
if (file_exists($image_path)) {
    unlink($image_path); // Hapus file dari folder uploads/
}

// Redirect kembali ke dashboard
header("Location: dashboard.php");
exit;
