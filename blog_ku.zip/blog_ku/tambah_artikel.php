<?php
session_start();
include 'config.php';

// Proteksi halaman: hanya untuk user yang login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Ambil daftar penulis & kategori untuk pilihan form
$penulis = $conn->query("SELECT * FROM author");
$kategori = $conn->query("SELECT * FROM category");

// Saat form disubmit
if (isset($_POST['submit'])) {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $author_id = $_POST['author'];
    $category_id = $_POST['category'];
    $published_at = date('Y-m-d');

    // Upload gambar
    $image_url = '';
    if (!empty($_FILES['image']['name'])) {
        $target_dir = "uploads/";
        $filename = time() . "_" . basename($_FILES["image"]["name"]);
        $target_file = $target_dir . $filename;
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image_url = $target_file;
        }
    }

    // Simpan ke tabel `article`
    $stmt = $conn->prepare("INSERT INTO article (title, content, image_url, published_at) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $title, $content, $image_url, $published_at);
    if ($stmt->execute()) {
        $article_id = $stmt->insert_id;

        // Simpan relasi penulis dan kategori
        $conn->query("INSERT INTO article_author (article_id, author_id) VALUES ($article_id, $author_id)");
        $conn->query("INSERT INTO article_category (article_id, category_id) VALUES ($article_id, $category_id)");

        header("Location: dashbor.php");
        exit;
    } else {
        echo "Gagal menyimpan artikel.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Artikel</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: url('assets/images/bg-tambah-artikel.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
        }

        .overlay {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: linear-gradient(to bottom, rgba(0,0,0,0.5), rgba(0,0,0,0.6));
            z-index: -1;
        }

        .form-container {
            max-width: 720px;
            margin: 100px auto;
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 12px 25px rgba(0,0,0,0.3);
            position: relative;
            z-index: 1;
        }

        h1 {
            text-align: center;
            color: #004d40;
            margin-bottom: 30px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }

        input[type="text"], select, textarea, input[type="file"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        textarea {
            height: 200px;
        }

        button {
            padding: 12px 20px;
            background: #00796b;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background: #005f56;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #00796b;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="overlay"></div>

<div class="form-container">
    <h1>Tambah Artikel Baru</h1>
    <form method="POST" enctype="multipart/form-data">
        <label for="title">Judul Artikel</label>
        <input type="text" name="title" required>

        <label for="author">Penulis</label>
        <select name="author" required>
            <option value="">-- Pilih Penulis --</option>
            <?php while ($row = $penulis->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['name']) ?></option>
            <?php endwhile; ?>
        </select>

        <label for="category">Kategori</label>
        <select name="category" required>
            <option value="">-- Pilih Kategori --</option>
            <?php while ($row = $kategori->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['name']) ?></option>
            <?php endwhile; ?>
        </select>

        <label for="image">Gambar Artikel</label>
        <input type="file" name="image" accept="image/*">

        <label for="content">Isi Artikel</label>
        <textarea name="content" required></textarea>

        <button type="submit" name="submit">Simpan Artikel</button>
    </form>
    <a href="dashbor.php" class="back-link">← Kembali ke Dashboard</a>
</div>
</body>
</html>
