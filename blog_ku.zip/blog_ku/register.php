<?php
include 'config.php';
session_start();

$error = "";
$success = "";

if (isset($_POST['submit'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm'];

    if ($password !== $confirm) {
        $error = "Password dan konfirmasi tidak cocok.";
    } else {
        // Cek apakah username sudah ada
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $error = "Username sudah digunakan.";
        } else {
            // Simpan user baru
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $insert = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $insert->bind_param("ss", $username, $hash);
            $insert->execute();
            $success = "Registrasi berhasil. Silakan login.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Register - Wisata Maluku</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: url('assets/images/bg-pantai.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        .overlay {
            background: rgba(0, 0, 0, 0.55);
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
        }

        .register-container {
            position: relative;
            z-index: 1;
            max-width: 460px;
            margin: 100px auto;
            background: white;
            padding: 35px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        }

        h1 {
            text-align: center;
            margin-bottom: 25px;
            color: #004d40;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #00796b;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background-color: #00695c;
        }

        .message {
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 0.95rem;
        }

        .error-message {
            background: #ffe0e0;
            color: #c62828;
        }

        .success-message {
            background: #e0f2f1;
            color: #2e7d32;
        }

        .bottom-link {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9rem;
        }

        .bottom-link a {
            color: #00796b;
            text-decoration: none;
        }

        .bottom-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="overlay"></div>

<div class="register-container">
    <h1>Registrasi</h1>

    <?php if ($error): ?>
        <div class="message error-message"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="message success-message"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST" action="register.php">
        <div class="form-group">
            <label for="username">Nama Pengguna</label>
            <input type="text" id="username" name="username" required autocomplete="off">
        </div>

        <div class="form-group">
            <label for="password">Kata Sandi</label>
            <input type="password" id="password" name="password" required>
        </div>

        <div class="form-group">
            <label for="confirm">Ulangi Kata Sandi</label>
            <input type="password" id="confirm" name="confirm" required>
        </div>

        <button type="submit" name="submit">Daftar</button>
    </form>

    <div class="bottom-link">
        Sudah punya akun? <a href="login.php">Login di sini</a><br>
        <a href="halaman.php">Kembali ke Beranda</a>
    </div>
</div>

</body>
</html>
