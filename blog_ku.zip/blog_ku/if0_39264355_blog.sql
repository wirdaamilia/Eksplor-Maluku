-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql300.infinityfree.com
-- Generation Time: Jun 18, 2025 at 11:57 AM
-- Server version: 10.6.19-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_39264355_blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `published_at` datetime NOT NULL DEFAULT current_timestamp(),
  `image_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `title`, `content`, `published_at`, `image_url`) VALUES
(3, 'Pesona Pantai Ora, Permata Tropis di Timur Indonesia', 'Ingin liburan yang benar-benar tenang, jauh dari hiruk-pikuk kota, dan menyatu dengan alam yang murni? Pantai Ora di Seram bagian utara, Maluku Tengah, adalah jawabannya.\r\n\r\nDengan pasir putih yang halus, laut sejernih kristal, dan pemandangan pegunungan hijau di kejauhan, Pantai Ora sering dijuluki sebagai “Maldives-nya Indonesia”. Di sini, Anda bisa menginap di bungalow apung langsung di atas laut—bangun pagi dengan panorama laut tropis tepat di depan mata.\r\n\r\nPantai ini sangat cocok bagi Anda yang mencari ketenangan, pasangan yang ingin bulan madu romantis, atau bahkan penikmat fotografi alam. Tak hanya pemandangan, keindahan bawah laut Pantai Ora juga luar biasa: terumbu karang warna-warni, ikan tropis, dan air yang begitu jernih membuat snorkeling jadi pengalaman yang tak terlupakan.\r\n\r\nAkses menuju Pantai Ora memang membutuhkan sedikit perjalanan, tapi percayalah, sesampainya di sana—lelah Anda akan terbayar lunas oleh keindahan yang belum tersentuh banyak orang.\r\n\r\nJangan lupa, waktu terbaik berkunjung ke Pantai Ora adalah antara bulan April hingga Oktober, saat cuaca cerah dan laut tenang.\r\n\r\nJadi, tunggu apa lagi? Rencanakan perjalanan Anda ke Pantai Ora sekarang dan rasakan sendiri ketenangan surga tersembunyi di Timur Indonesia.', '2025-06-14 00:00:00', 'uploads/1749901975_Pantai Ora, Maluku Tengah.jpg'),
(4, '“Berani Coba? Papeda, Makanan Maluku yang Tidak Dikunyah tapi Bikin Ketagihan”', 'Jika kamu berani mencoba sesuatu yang berbeda dan eksotis, maka Papeda adalah makanan yang wajib kamu cicipi saat berkunjung ke Maluku. Makanan ini bukan sekadar kuliner biasa — ini adalah pengalaman budaya yang tak terlupakan.\r\n\r\nPapeda adalah bubur sagu khas Maluku yang tampil beda. Teksturnya? Lengket, bening, dan kenyal seperti lem. Cara makannya? Tidak dikunyah! Cukup diseruput dan langsung telan. Aneh? Mungkin. Tapi justru di sanalah daya tariknya.\r\n\r\nBiasanya, Papeda disajikan dengan ikan kuah kuning yang gurih dan wangi rempah. Kombinasinya sungguh unik: rasa netral papeda bertemu kuah kaya rasa. Sekali coba, kamu mungkin akan berkata, “Kenapa aku baru tahu makanan ini sekarang?”\r\n\r\nBagi masyarakat Maluku, Papeda bukan sekadar makanan — ini adalah simbol tradisi, kebersamaan, dan warisan leluhur. Makan Papeda selalu disajikan dalam wadah besar, dimakan rame-rame, dan penuh canda tawa.\r\n\r\nOh ya, Papeda juga sehat, lho! Dibuat dari sagu murni yang rendah gula dan tinggi serat. Cocok buat kamu yang sedang diet atau ingin hidup lebih alami.\r\n\r\nJadi, siap mencoba pengalaman makan tanpa mengunyah? Jangan pulang dari Maluku sebelum mencicipi Papeda. Tapi hati-hati... bisa-bisa kamu jadi ketagihan!', '2025-06-14 00:00:00', 'uploads/1749902608_Papeda (sago congee), Kuah Kuning (yelow soup) and Ikan Tude Bakar (grilled fish) with Dabu-dabu and Rica sambal_ The Eastern Indonesian meal; Papeda, the staple food of Eastern Indonesia have a glue-like co.jpg'),
(5, '“Pantai Jikumarasa: Keindahan Rahasia di Ujung Pulau Buru”', 'Kalau kamu ingin menemukan pantai yang belum terlalu ramai tapi tetap memukau, maka Pantai Jikumarasa di Kabupaten Buru adalah destinasi yang wajib kamu kunjungi. Terletak di Desa Jikumarasa, Kecamatan Lilialy, pantai ini menyuguhkan panorama pasir putih halus, laut biru jernih, dan suasana damai yang jarang ditemukan di tempat lain.\r\n\r\nPantai ini masih sangat alami. Tidak ada bangunan beton tinggi atau keramaian wisata massal—yang ada hanyalah ombak tenang, suara angin, dan jejak kaki sendiri di pasir. Ini adalah tempat ideal untuk kamu yang ingin “melarikan diri sejenak” dari rutinitas.\r\n\r\nMenariknya lagi, di sekitar pantai ini kamu bisa menemukan perahu-perahu nelayan lokal yang bersandar rapi, menambah suasana khas pesisir Maluku. Jika kamu beruntung, kamu bisa membeli ikan segar langsung dari nelayan dan membakarnya di pinggir pantai!\r\n\r\nAkses menuju Pantai Jikumarasa memang memerlukan usaha, karena letaknya agak jauh dari pusat kota Namlea. Namun justru karena itulah, pantai ini tetap asri, bersih, dan tenang—bebas dari hiruk pikuk wisatawan.\r\n\r\nPantai ini juga cocok untuk kegiatan seperti piknik keluarga, camping, atau sekadar duduk sore menikmati sunset. Langit di Buru bagian barat bisa menjadi kanvas matahari terbenam yang luar biasa indah.\r\n\r\nJadi, kalau kamu sedang berada di Pulau Buru atau berencana ke Maluku, pastikan Pantai Jikumarasa masuk dalam daftar kunjunganmu. Tempat ini bukan hanya indah, tapi juga menghadirkan pengalaman tenang yang mungkin kamu butuhkan tanpa sadar.', '2025-06-18 00:00:00', 'uploads/1750224583_pantai-jikumarasa-2025-06-18-WAA.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `article_author`
--

CREATE TABLE `article_author` (
  `article_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `article_author`
--

INSERT INTO `article_author` (`article_id`, `author_id`) VALUES
(3, 5),
(4, 5),
(5, 5),
(3, 5),
(4, 5),
(5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `article_category`
--

CREATE TABLE `article_category` (
  `article_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `article_category`
--

INSERT INTO `article_category` (`article_id`, `category_id`) VALUES
(3, 2),
(4, 3),
(5, 2),
(3, 2),
(4, 3),
(5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

CREATE TABLE `author` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `bio` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `author`
--

INSERT INTO `author` (`id`, `name`, `email`, `bio`) VALUES
(5, 'Wirda Amilia', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(2, 'Pantai'),
(3, 'Kuliner Khas'),
(4, 'Budaya & Sejarah');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `article_id` int(11) DEFAULT NULL,
  `author_name` varchar(100) DEFAULT NULL,
  `comment_text` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'wirdaamilia', '$2y$10$a9u0vUiqJCOTlRsy/Nqseuj3vuoOOrGCdUJfexa.wAuz/L43cZ0fO');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `article_author`
--
ALTER TABLE `article_author`
  ADD KEY `FK__article` (`article_id`),
  ADD KEY `FK_author` (`author_id`);

--
-- Indexes for table `article_category`
--
ALTER TABLE `article_category`
  ADD KEY `FK_article` (`article_id`),
  ADD KEY `FK_category` (`category_id`);

--
-- Indexes for table `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `article_id` (`article_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `author`
--
ALTER TABLE `author`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `article_author`
--
ALTER TABLE `article_author`
  ADD CONSTRAINT `FK__article` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`),
  ADD CONSTRAINT `FK_author` FOREIGN KEY (`author_id`) REFERENCES `author` (`id`);

--
-- Constraints for table `article_category`
--
ALTER TABLE `article_category`
  ADD CONSTRAINT `FK_article` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`),
  ADD CONSTRAINT `FK_category` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`);

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
