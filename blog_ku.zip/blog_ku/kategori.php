<?php
include 'config.php';

$kategori_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Ambil nama kategori
$kategori_nama = "";
$kategori_result = $conn->query("SELECT name FROM category WHERE id = $kategori_id");
if ($kategori_result->num_rows > 0) {
    $kategori_nama = $kategori_result->fetch_assoc()['name'];
}

// Ambil artikel berdasarkan kategori
$sql = "
    SELECT a.id, a.title, a.published_at, a.content, a.image_url
    FROM article a
    JOIN article_category ac ON a.id = ac.article_id
    WHERE ac.category_id = $kategori_id
    ORDER BY a.published_at DESC
";
$artikel = $conn->query($sql);

// Ambil kategori untuk sidebar
$kategori = $conn->query("SELECT * FROM category");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Artikel Kategori: <?= htmlspecialchars($kategori_nama) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        /* gunakan style bawaan dari halaman.php */
        .container {
            max-width: 1000px;
            margin: 30px auto;
            display: flex;
            gap: 30px;
        }

        .left {
            flex: 3;
        }

        .right {
            flex: 1;
        }

        .sidebar-section {
            background: white;
            border: 1px solid #eee;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .sidebar-section h3 {
            margin-bottom: 15px;
            font-size: 1.2rem;
            color: #004d40;
        }

        header {
            background-color: #ffffff;
            padding: 40px 20px;
            text-align: center;
            border-bottom: 1px solid #e0e0e0;
        }

        header h1 {
            font-size: 2.3rem;
            margin-bottom: 10px;
            color: #004d40;
        }

        .navbar {
            background-color: #004d40;
            padding: 10px 0;
        }

        .navbar .container {
            max-width: 1000px;
            margin: auto;
            display: flex;
            gap: 30px;
        }

        .nav-link {
            color: white;
            text-decoration: none;
            font-size: 1rem;
        }

        .nav-link:hover {
            text-decoration: underline;
        }

        footer {
            text-align: center;
            padding: 20px;
            background: #004d40;
            color: white;
            margin-top: 40px;
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
            overflow: hidden;
            margin-bottom: 30px;
            transition: transform 0.2s ease;
        }

        .card:hover {
            transform: translateY(-4px);
        }

        .card-img {
            width: 100%;
            height: 220px;
            object-fit: cover;
        }

        .card-body {
            padding: 20px;
        }

        .card-title {
            font-size: 1.5rem;
            color: #00695c;
            margin-bottom: 8px;
        }

        .meta {
            font-size: 0.85rem;
            color: #999;
            margin-bottom: 12px;
        }

        .read-more {
            color: #00897b;
            font-weight: bold;
            text-decoration: none;
        }

        .read-more:hover {
            text-decoration: underline;
        }

        .search-form input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            margin-bottom: 10px;
        }

        .search-form button {
            width: 100%;
            padding: 10px;
            background: #00897b;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .search-form button:hover {
            background: #00796b;
        }
    </style>
</head>
<body>

<header>
    <h1>Kategori: <?= htmlspecialchars($kategori_nama) ?></h1>
</header>

<!-- Navigasi -->
<nav class="navbar">
    <div class="container">
        <a href="index.php" class="nav-link">Beranda</a>
        <a href="kategori.php" class="nav-link">Kategori</a>
        <a href="login.php" class="nav-link">Login</a>
    </div>
</nav>

<div class="container">
    <div class="left">
        <?php if ($artikel->num_rows > 0): ?>
            <?php while ($row = $artikel->fetch_assoc()): ?>
                <div class="card">
                    <img src="<?= $row['image_url'] ?>" class="card-img" alt="Gambar Artikel">
                    <div class="card-body">
                        <h2 class="card-title"><?= htmlspecialchars($row['title']) ?></h2>
                        <p class="meta"><?= $row['published_at'] ?></p>
                        <p class="content"><?= substr(strip_tags($row['content']), 0, 150) ?>...</p>
                        <a href="article.php?id=<?= $row['id'] ?>" class="read-more">Baca Selengkapnya</a>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Tidak ada artikel dalam kategori ini.</p>
        <?php endif; ?>
    </div>

    <!-- Sidebar -->
    <div class="right">
        <div class="sidebar-section">
            <h3>Pencarian</h3>
            <form class="search-form" action="index.php" method="get">
                <input type="text" name="search" placeholder="Cari artikel...">
                <button type="submit">Cari</button>
            </form>
        </div>

        <div class="sidebar-section">
            <h3>Kategori</h3>
            <ul>
                <?php mysqli_data_seek($kategori, 0); while ($kat = $kategori->fetch_assoc()): ?>
                    <li><a href="kategori.php?id=<?= $kat['id'] ?>"><?= htmlspecialchars($kat['name']) ?></a></li>
                <?php endwhile; ?>
            </ul>
        </div>

        <div class="sidebar-section">
            <h3>Tentang</h3>
            <p>Menampilkan berbagai destinasi wisata di Maluku berdasarkan kategori pilihan Anda.</p>
        </div>
    </div>
</div>

<!-- Footer -->
<footer>
    &copy; <?= date('Y') ?> Eksplor Maluku. Menyusuri Keindahan Alam, Budaya, dan Rasa.
</footer>

</body>
</html>
