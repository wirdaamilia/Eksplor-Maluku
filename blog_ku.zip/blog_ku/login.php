<?php
session_start();
include 'config.php';

if (isset($_SESSION['user_id'])) {
    header("Location: dashbor.php");
    exit;
}

$error = "";

if (isset($_POST['submit'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        $error = "Username tidak ditemukan.";
    } elseif (!password_verify($password, $user['password'])) {
        $error = "Password salah.";
    } else {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $username;
        header("Location: dashbor.php");
        exit;
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - Eksplor Maluku</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: url('assets/images/bg-pantai.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        .overlay {
            background: rgba(0, 0, 0, 0.55);
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
        }

        .login-container {
            position: relative;
            z-index: 1;
            max-width: 420px;
            margin: 100px auto;
            background: white;
            padding: 35px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        }

        h1 {
            text-align: center;
            margin-bottom: 25px;
            color: #004d40;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #00796b;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background-color: #00695c;
        }

        .error-message {
            background: #ffe0e0;
            color: #c62828;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 0.95rem;
        }

        .bottom-link {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9rem;
        }

        .bottom-link a {
            color: #00796b;
            text-decoration: none;
        }

        .bottom-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="overlay"></div>

<div class="login-container">
    <h1>Login Admin</h1>

    <?php if ($error): ?>
        <div class="error-message"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="login.php">
        <div class="form-group">
            <label for="username">Nama Pengguna</label>
            <input type="text" id="username" name="username" required autocomplete="off">
        </div>
        <div class="form-group">
            <label for="password">Kata Sandi</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" name="submit">Masuk</button>
    </form>

    <div class="bottom-link">
        Belum punya akun? <a href="register.php">Daftar</a><br>
        <a href="halaman.php">Kembali ke Beranda</a>
    </div>
</div>

</body>
</html>
