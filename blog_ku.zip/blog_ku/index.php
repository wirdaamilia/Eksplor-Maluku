<?php
include 'config.php';

// Ambil keyword pencarian jika ada
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Fungsi highlight dengan animasi
function highlight($text, $keyword) {
    if (!$keyword) return $text;
    return preg_replace("/(" . preg_quote($keyword, '/') . ")/i", "<mark>$1</mark>", $text);
}

// Query artikel
if ($search !== '') {
    $stmt = $conn->prepare("
        SELECT id, title, published_at, content, image_url
        FROM article
        WHERE title LIKE CONCAT('%', ?, '%') OR content LIKE CONCAT('%', ?, '%')
        ORDER BY published_at DESC
    ");
    $stmt->bind_param("ss", $search, $search);
    $stmt->execute();
    $artikel = $stmt->get_result();
} else {
    $artikel = $conn->query("
        SELECT id, title, published_at, content, image_url
        FROM article
        ORDER BY published_at DESC
        LIMIT 7
    ");
}

// Ambil kategori untuk sidebar
$kategori = $conn->query("SELECT * FROM category");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Eksplor Maluku: Menyusuri Keindahan Alam, Budaya, dan Rasa</title>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Merriweather', serif;
            background-color: #f4f6f8;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #ffffff;
            padding: 40px 20px;
            text-align: center;
            border-bottom: 1px solid #e0e0e0;
        }

        header h1 {
            font-size: 2.8rem;
            margin-bottom: 10px;
            color: #004d40;
        }

        header p {
            font-size: 1.1rem;
            color: #666;
        }

        .navbar {
            background-color: #004d40;
            padding: 10px 0;
        }

        .navbar .container {
            max-width: 1000px;
            margin: auto;
            display: flex;
            gap: 30px;
        }

        .nav-link {
            color: white;
            text-decoration: none;
            font-size: 1rem;
        }

        .nav-link:hover {
            text-decoration: underline;
        }

        .container {
            max-width: 1000px;
            margin: 30px auto;
            display: flex;
            gap: 30px;
        }

        .left {
            flex: 3;
        }

        .right {
            flex: 1;
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
            overflow: hidden;
            margin-bottom: 30px;
            transition: transform 0.2s ease;
        }

        .card:hover {
            transform: translateY(-4px);
        }

        .card-img {
            width: 100%;
            height: 220px;
            object-fit: cover;
        }

        .card-body {
            padding: 20px;
        }

        .card-title {
            font-size: 1.5rem;
            color: #00695c;
            margin-bottom: 8px;
        }

        .meta {
            font-size: 0.85rem;
            color: #999;
            margin-bottom: 12px;
        }

        .content {
            font-size: 1rem;
            line-height: 1.6;
            color: #444;
        }

        .read-more {
            display: inline-block;
            margin-top: 10px;
            text-decoration: none;
            color: #00897b;
            font-weight: bold;
        }

        .read-more:hover {
            text-decoration: underline;
        }

        .sidebar-section {
            background: white;
            border: 1px solid #eee;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .sidebar-section h3 {
            margin-bottom: 15px;
            font-size: 1.2rem;
            color: #004d40;
        }

        .sidebar-section ul {
            padding-left: 20px;
        }

        .sidebar-section ul li {
            margin-bottom: 8px;
        }

        .sidebar-section a {
            text-decoration: none;
            color: #00796b;
        }

        .sidebar-section a:hover {
            text-decoration: underline;
        }

        .search-form input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            margin-bottom: 10px;
        }

        .search-form button {
            width: 100%;
            padding: 10px;
            background: #00897b;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .search-form button:hover {
            background: #00796b;
        }

        mark {
            background-color: #fff176;
            padding: 2px 4px;
            border-radius: 4px;
            animation: fadeHighlight 0.5s ease-in-out;
        }

        @keyframes fadeHighlight {
            from {
                background-color: transparent;
                color: transparent;
            }
            to {
                background-color: #fff176;
                color: inherit;
            }
        }

        footer {
            text-align: center;
            padding: 20px;
            background: #004d40;
            color: white;
            margin-top: 40px;
        }
    </style>
</head>
<body>

<!-- Header -->
<header>
    <h1>Eksplor Maluku</h1>
    <p>Menyusuri Keindahan Alam, Budaya, dan Rasa</p>
</header>

<!-- Navigasi -->
<nav class="navbar">
    <div class="container">
        <a href="index.php" class="nav-link">Beranda</a>
        <a href="kategori.php" class="nav-link">Kategori</a>
        <a href="login.php" class="nav-link">Login</a>
    </div>
</nav>

<!-- Konten Utama -->
<div class="container">
    <!-- Kolom Kiri: Artikel -->
    <div class="left">
        <?php if ($search !== ''): ?>
            <p><strong>Ditemukan hasil pencarian untuk: "<?= htmlspecialchars($search) ?>"</strong></p>
        <?php endif; ?>

        <?php if ($artikel->num_rows > 0): ?>
            <?php while ($row = $artikel->fetch_assoc()): ?>
                <div class="card">
                    <img src="<?= $row['image_url'] ?>" class="card-img" alt="Gambar Artikel">
                    <div class="card-body">
                        <h2 class="card-title"><?= highlight(htmlspecialchars($row['title']), $search) ?></h2>
                        <p class="meta"><?= $row['published_at'] ?></p>
                        <p class="content"><?= highlight(substr(strip_tags($row['content']), 0, 150), $search) ?>...</p>
                        <a href="article.php?id=<?= $row['id'] ?>" class="read-more">Baca Selengkapnya</a>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Tidak ada artikel yang ditemukan.</p>
        <?php endif; ?>
    </div>

    <!-- Kolom Kanan: Sidebar -->
    <div class="right">
        <!-- Pencarian -->
        <div class="sidebar-section">
            <h3>Pencarian</h3>
            <form class="search-form" action="index.php" method="get">
                <input type="text" name="search" placeholder="Cari artikel..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit">Cari</button>
            </form>
        </div>

        <!-- Kategori -->
        <div class="sidebar-section">
            <h3>Kategori</h3>
            <ul>
                <?php while ($kat = $kategori->fetch_assoc()): ?>
                    <li><a href="kategori.php?id=<?= $kat['id'] ?>"><?= htmlspecialchars($kat['name']) ?></a></li>
                <?php endwhile; ?>
            </ul>
        </div>

        <!-- Tentang -->
        <div class="sidebar-section">
            <h3>Tentang</h3>
            <p> <!-- Tentang -->
        <div class="sidebar-section">
            <h3>Tentang</h3>
            <p>Website ini menampilkan berbagai tempat wisata menarik di Maluku — dari pantai eksotis, budaya lokal, hingga kuliner tradisional.</p>
        </div>
    </div>
</div></p>
        </div>
    </div>
</div>

<!-- Footer -->
<footer>
    &copy; <?= date('Y') ?> Tempat Wisata di Maluku. All rights reserved.
</footer>

</body>
</html>
