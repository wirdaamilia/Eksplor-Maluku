<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Artikel tidak ditemukan.";
    exit;
}

$id = intval($_GET['id']);

// Ambil data artikel
$artikel = $conn->query("SELECT * FROM article WHERE id = $id")->fetch_assoc();

// Ambil daftar penulis & kategori
$penulis = $conn->query("SELECT * FROM author");
$kategori = $conn->query("SELECT * FROM category");

// Ambil id author dan category terpilih
$curr_author = $conn->query("SELECT author_id FROM article_author WHERE article_id = $id")->fetch_assoc()['author_id'] ?? '';
$curr_category = $conn->query("SELECT category_id FROM article_category WHERE article_id = $id")->fetch_assoc()['category_id'] ?? '';

// Jika form disubmit
if (isset($_POST['submit'])) {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $author_id = $_POST['author'];
    $category_id = $_POST['category'];
    $published_at = date('Y-m-d');

    // Cek dan simpan upload gambar (jika diubah)
    $image_url = $artikel['image_url'];
    if (!empty($_FILES['image']['name'])) {
        $target_dir = "uploads/";
        $filename = time() . "_" . basename($_FILES["image"]["name"]);
        $target_file = $target_dir . $filename;
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image_url = $target_file;
        }
    }

    // Update tabel utama
    $stmt = $conn->prepare("UPDATE article SET title = ?, content = ?, published_at = ?, image_url = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $title, $content, $published_at, $image_url, $id);
    
    if ($stmt->execute()) {
        // Update relasi
        $conn->query("DELETE FROM article_author WHERE article_id = $id");
        $conn->query("DELETE FROM article_category WHERE article_id = $id");

        $conn->query("INSERT INTO article_author (article_id, author_id) VALUES ($id, $author_id)");
        $conn->query("INSERT INTO article_category (article_id, category_id) VALUES ($id, $category_id)");

        header("Location: dashbor.php");
        exit;
    } else {
        echo "Gagal menyimpan perubahan artikel.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Artikel</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: url('assets/images/bg-tambah-artikel.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
        }

        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(to bottom, rgba(0,0,0,0.45), rgba(0,0,0,0.65));
            width: 100%;
            height: 100%;
            z-index: -1;
        }

        .form-container {
            max-width: 700px;
            margin: 80px auto;
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
            position: relative;
            z-index: 1;
        }

        h1 {
            text-align: center;
            color: #004d40;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }

        input[type="text"],
        select,
        textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 1rem;
        }

        textarea {
            height: 200px;
        }

        button {
            padding: 12px 20px;
            background: #00796b;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #00796b;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="overlay"></div>

<div class="form-container">
    <h1>Edit Artikel</h1>
    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Judul Artikel</label>
            <input type="text" name="title" value="<?= htmlspecialchars($artikel['title']) ?>" required>
        </div>

        <div class="form-group">
            <label for="author">Penulis</label>
            <select name="author" required>
                <?php while ($a = $penulis->fetch_assoc()): ?>
                    <option value="<?= $a['id'] ?>" <?= $a['id'] == $curr_author ? 'selected' : '' ?>><?= htmlspecialchars($a['name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="category">Kategori</label>
            <select name="category" required>
                <?php while ($k = $kategori->fetch_assoc()): ?>
                    <option value="<?= $k['id'] ?>" <?= $k['id'] == $curr_category ? 'selected' : '' ?>><?= htmlspecialchars($k['name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="image">Ganti Gambar (Opsional)</label>
            <input type="file" name="image" accept="image/*">
        </div>

        <div class="form-group">
            <label for="content">Isi Artikel</label>
            <textarea name="content" required><?= htmlspecialchars($artikel['content']) ?></textarea>
        </div>

        <button type="submit" name="submit">Simpan Perubahan</button>
    </form>
    <a href="dashbor.php" class="back-link">← Kembali ke Dashboard</a>
</div>
</body>
</html>
