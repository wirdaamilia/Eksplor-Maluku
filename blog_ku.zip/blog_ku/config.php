<?php 
$host = "127.0.0.1:3307";
$username = "root";
$password = "";
$database = "blog_db";

// ganti dari $koneksi menjadi $conn
$conn = mysqli_connect($host, $username, $password, $database);

if ($conn) {
} else {
    echo "Server not connected";
}
?>
