<?php
session_start();
session_unset();      // Hapus semua variabel sesi
session_destroy();    // Hancurkan sesi aktif

// Redirect ke halaman login atau beranda
header("Location: login.php");
exit;
?>
