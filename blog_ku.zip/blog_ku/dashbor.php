<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'] ?? 'Admin';

// Hitung total data
$article_count = $conn->query("SELECT COUNT(*) AS total FROM article")->fetch_assoc()['total'];
$author_count = $conn->query("SELECT COUNT(*) AS total FROM author")->fetch_assoc()['total'];
$category_count = $conn->query("SELECT COUNT(*) AS total FROM category")->fetch_assoc()['total'];

// Ambil daftar artikel
$articles = $conn->query("SELECT id, title, published_at FROM article ORDER BY published_at DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin - Wisata Maluku</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: #f1f4f7;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .navbar {
            background: #004d40;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
        }

        .navbar h1 {
            margin: 0;
            font-size: 1.5rem;
        }

        .navbar .user {
            font-size: 0.95rem;
        }

        .logout-btn {
            color: #ffcccb;
            font-weight: 500;
            margin-left: 10px;
            text-decoration: none;
        }

        .logout-btn:hover {
            color: #ffffff;
            text-decoration: underline;
        }

        .container {
            max-width: 1000px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .summary {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            flex: 1;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            text-align: center;
        }

        .card h2 {
            font-size: 2.4rem;
            color: #00796b;
            margin: 0;
        }

        .card p {
            margin-top: 8px;
            font-weight: 500;
            color: #555;
        }

        .actions {
            margin-bottom: 20px;
            text-align: center;
        }

        .actions a {
            background: #00796b;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 6px;
            font-weight: 500;
        }

        .actions a:hover {
            background: #00695c;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.04);
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 14px 16px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        th {
            background: #f5f5f5;
            color: #333;
        }

        a.btn {
            padding: 6px 12px;
            text-decoration: none;
            font-size: 0.9rem;
            border-radius: 4px;
            margin-right: 8px;
            color: white;
        }

        .btn-edit {
            background: #3498db;
        }

        .btn-delete {
            background: #e74c3c;
        }

        .btn-edit:hover { background: #2980b9; }
        .btn-delete:hover { background: #c0392b; }

        footer {
            margin-top: 40px;
            padding: 20px;
            background: #004d40;
            text-align: center;
            color: white;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<div class="navbar">
    <h1>Dashboard Admin</h1>
    <div class="user">
        <?= htmlspecialchars($username) ?> |
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</div>

<div class="container">

    <!-- Summary Cards -->
    <div class="summary">
        <div class="card">
            <h2><?= $article_count ?></h2>
            <p>Artikel</p>
        </div>
        <div class="card">
            <h2><?= $author_count ?></h2>
            <p>Penulis</p>
        </div>
        <div class="card">
            <h2><?= $category_count ?></h2>
            <p>Kategori</p>
        </div>
    </div>

    <!-- Aksi -->
    <div class="actions">
        <a href="tambah_artikel.php">Tambah Artikel</a>
        <a href="author_crud.php">Kelola Penulis</a>
        <a href="category_crud.php">Kelola Kategori</a>
    </div>

    <!-- Tabel Artikel -->
    <h2 style="margin-bottom: 10px;">Daftar Artikel</h2>
    <table>
        <tr>
            <th>Judul</th>
            <th>Tanggal</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = $articles->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['title']) ?></td>
                <td><?= $row['published_at'] ?></td>
                <td>
                    <a class="btn btn-edit" href="edit_artikel.php?id=<?= $row['id'] ?>">Edit</a>
                    <a class="btn btn-delete" href="hapus_artikel.php?id=<?= $row['id'] ?>" onclick="return confirm('Yakin hapus?')">Hapus</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

</div>

<!-- Footer -->
<footer>
    &copy; <?= date('Y') ?> Eksplor Maluku. Menyusuri Keindahan Alam, Budaya, dan Rasa. Panel Admin.
</footer>

</body>
</html> 
