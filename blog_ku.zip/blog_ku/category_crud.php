<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (isset($_POST['tambah'])) {
    $name = trim($_POST['name']);
    if ($name !== '') {
        $stmt = $conn->prepare("INSERT INTO category (name) VALUES (?)");
        $stmt->bind_param("s", $name);
        $stmt->execute();
    }
    header("Location: category_crud.php");
    exit;
}

if (isset($_POST['edit'])) {
    $id = $_POST['id'];
    $name = trim($_POST['name']);
    if ($name !== '') {
        $stmt = $conn->prepare("UPDATE category SET name = ? WHERE id = ?");
        $stmt->bind_param("si", $name, $id);
        $stmt->execute();
    }
    header("Location: category_crud.php");
    exit;
}

if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $conn->query("DELETE FROM category WHERE id = $id");
    header("Location: category_crud.php");
    exit;
}

$data = $conn->query("SELECT * FROM category ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Kategori</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: url('assets/images/bg-tambah-artikel.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            position: relative;
        }

        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(to bottom, rgba(0,0,0,0.45), rgba(0,0,0,0.65));
            width: 100%;
            height: 100%;
            z-index: -1;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .crud-container {
            max-width: 600px;
            margin: 100px auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.25);
            animation: fadeIn 0.8s ease-out;
            position: relative;
            z-index: 1;
        }

        h2 {
            margin-bottom: 20px;
            color: #004d40;
            text-align: center;
        }

        input[type="text"] {
            width: calc(100% - 20px);
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }

        button {
            padding: 10px 20px;
            background: #00796b;
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
            background: #f9f9f9;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid #ccc;
        }

        a {
            margin-right: 10px;
            color: #00796b;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #00796b;
            font-size: 0.95rem;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="overlay"></div>
<div class="crud-container">
    <h2>Kelola Kategori</h2>

    <form method="POST">
        <input type="text" name="name" placeholder="Nama Kategori" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>

    <table>
        <tr><th>Nama</th><th>Aksi</th></tr>
        <?php while ($row = $data->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td>
                <a href="?edit_id=<?= $row['id'] ?>">Edit</a>
                <a href="?hapus=<?= $row['id'] ?>" onclick="return confirm('Yakin hapus?')">Hapus</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <?php if (isset($_GET['edit_id'])):
        $edit_id = $_GET['edit_id'];
        $edit = $conn->query("SELECT * FROM category WHERE id = $edit_id")->fetch_assoc();
    ?>
    <hr>
    <h3>Edit Kategori</h3>
    <form method="POST">
        <input type="hidden" name="id" value="<?= $edit['id'] ?>">
        <input type="text" name="name" value="<?= htmlspecialchars($edit['name']) ?>" required>
        <button type="submit" name="edit">Simpan Perubahan</button>
    </form>
    <?php endif; ?>

    <a href="dashbor.php" class="back-link">← Kembali ke Dashboard</a>
</div>
</body>
</html>
