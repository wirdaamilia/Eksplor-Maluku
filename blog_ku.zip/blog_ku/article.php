<?php
include 'config.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Artikel tidak ditemukan.";
    exit;
}

$id = intval($_GET['id']);

// Ambil data utama artikel
$sql = "SELECT id, title, published_at, content, image_url FROM article WHERE id = $id LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows === 0) {
    echo "Artikel tidak ditemukan.";
    exit;
}

$artikel = $result->fetch_assoc();

// Ambil penulis
$penulis = [];
$penulis_q = $conn->query("
    SELECT author.name 
    FROM author
    JOIN article_author ON author.id = article_author.author_id
    WHERE article_author.article_id = $id
");
while ($row = $penulis_q->fetch_assoc()) {
    $penulis[] = $row['name'];
}

// Ambil kategori
$kategori = [];
$kategori_q = $conn->query("
    SELECT category.id, category.name 
    FROM category
    JOIN article_category ON category.id = article_category.category_id
    WHERE article_category.article_id = $id
");
while ($row = $kategori_q->fetch_assoc()) {
    $kategori[] = $row;
}

// Ambil artikel terkait berdasarkan kategori pertama
$terkait = [];
if (!empty($kategori)) {
    $kategori_id = intval($kategori[0]['id']);
    $terkait = $conn->query("
        SELECT a.id, a.title 
        FROM article a
        JOIN article_category ac ON a.id = ac.article_id
        WHERE ac.category_id = $kategori_id AND a.id != $id
        ORDER BY a.published_at DESC
        LIMIT 5
    ");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($artikel['title']) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Merriweather', serif;
            background-color: #f4f6f8;
            margin: 0;
        }

        header {
            background: #ffffff;
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        header h1 {
            font-size: 2.2rem;
            color: #004d40;
        }

        .meta {
            font-size: 0.9rem;
            color: #777;
            margin-top: 10px;
        }

        .navbar {
            background-color: #004d40;
            padding: 10px 0;
        }

        .navbar .container {
            max-width: 1000px;
            margin: auto;
            display: flex;
            gap: 30px;
        }

        .nav-link {
            color: white;
            text-decoration: none;
            font-size: 1rem;
        }

        .nav-link:hover {
            text-decoration: underline;
        }

        .container {
            max-width: 1000px;
            margin: 30px auto;
            display: flex;
            gap: 30px;
        }

        .left {
            flex: 3;
        }

        .right {
            flex: 1;
        }

        .detail-img {
            width: 100%;
            max-height: 400px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .content {
            font-size: 1.05rem;
            line-height: 1.7;
            color: #444;
        }

        .sidebar-section {
            background: white;
            border: 1px solid #eee;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .sidebar-section h3 {
            font-size: 1.2rem;
            margin-bottom: 15px;
            color: #004d40;
        }

        .sidebar-section ul {
            padding-left: 20px;
        }

        .sidebar-section ul li {
            margin-bottom: 8px;
        }

        .sidebar-section a {
            color: #00796b;
            text-decoration: none;
        }

        .sidebar-section a:hover {
            text-decoration: underline;
        }

        footer {
            text-align: center;
            padding: 20px;
            background: #004d40;
            color: white;
            margin-top: 40px;
        }

        .search-form input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            margin-bottom: 10px;
        }

        .search-form button {
            width: 100%;
            padding: 10px;
            background: #00897b;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .search-form button:hover {
            background: #00796b;
        }
    </style>
</head>
<body>

<!-- Navigasi -->
<nav class="navbar">
    <div class="container">
        <a href="index.php" class="nav-link">Beranda</a>
        <a href="kategori.php" class="nav-link">Kategori</a>
        <a href="login.php" class="nav-link">Login</a>
    </div>
</nav>

<!-- Header -->
<header>
    <h1><?= htmlspecialchars($artikel['title']) ?></h1>
    <div class="meta">
        <?= date('d M Y', strtotime($artikel['published_at'])) ?> |
        <?= implode(', ', $penulis) ?> |
        <?= implode(', ', array_column($kategori, 'name')) ?>
    </div>
</header>

<!-- Konten -->
<div class="container">
    <div class="left">
        <?php if (!empty($artikel['image_url'])): ?>
            <img src="<?= htmlspecialchars($artikel['image_url']) ?>" class="detail-img" alt="Gambar Artikel">
        <?php endif; ?>
        <div class="content">
            <?= nl2br(htmlspecialchars($artikel['content'])) ?>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="right">
        <div class="sidebar-section">
            <h3>Pencarian</h3>
            <form class="search-form" action="index.php" method="get">
                <input type="text" name="search" placeholder="Cari artikel...">
                <button type="submit">Cari</button>
            </form>
        </div>

        <div class="sidebar-section">
            <h3>Artikel Terkait</h3>
            <ul>
                <?php if ($terkait && $terkait->num_rows > 0): ?>
                    <?php while ($t = $terkait->fetch_assoc()): ?>
                        <li><a href="article.php?id=<?= $t['id'] ?>"><?= htmlspecialchars($t['title']) ?></a></li>
                    <?php endwhile; ?>
                <?php else: ?>
                    <li>Tidak ada artikel terkait.</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>

<!-- Footer -->
<footer>
    &copy; <?= date('Y') ?> Eksplor Maluku. Menyusuri Keindahan Alam, Budaya, dan Rasa.
</footer>

</body>
</html>
